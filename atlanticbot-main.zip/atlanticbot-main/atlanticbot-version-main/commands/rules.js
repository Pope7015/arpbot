module.exports = {
    name: 'rules',
    description: 'A Command.',
    aliases: ['credits', 'hyperz'],
    async execute(client, message, args, Hyperz, config) {
        const pingEmbed = new Hyperz.MessageEmbed()
            .setColor(config["main_config"].colorhex)
            .setTitle('Server Rules')
            .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, `${config["other_configuration"].serverinvite}`)
            .setDescription(`**Discord Rules**

            1 - No Spam links (   will touch your balls if you post some stupid shit)
            2 - No Racism or homophobic remarks.
            3 - Use the proper channels for stuff, don't go asking for support in #:robot:bot-commands or #:speech_balloon:general you can't be banned but it's just more orginized that way.
            4 - Don't be a dick to other members just cause y'all had history, take it to DM's.

            **FiveM Rules**

            1 - No RDM, VDM, Mass RDM, Mass VDM ect.
            
            2 - No Racial Slurs (This is common sense and is a perma ban ;0)
            
            3 - No Stealing LEO vehicles without it being the only way of escape. 
            
            4 - Don't leech to one area, try and make the Roleplay interesting for other people.
            
            5 - Attacking SAFR is not allowed as they are a neutral this also goes for stealing their vehicles, you **cant** do this.
            
            6 - There is no "100k or die" we are not a gang server, we don't all have 50 bil up our anal cavity.
            
            7 - Force RP is a thing, just to a extent. You can rob people but not take them hostage without them consenting to it.
            
            8 - No re-creations of any events like *9-1-1* if seen you can be banned.
            
            9 - No Trolling. We allow content creators, but we don't allow just plain trolling.
            
            10 - Don't minimod. You are not allowed to say "your getting banned" or "your getting kicked".
            
            11 - No impersonation of a Staff, LEO, Or Fire Department. This is final.
            
            This document is subject to change`)
            .setTimestamp()
            .setFooter(`${config["main_config"].copyright}`)

        message.channel.send(pingEmbed).then(msg => msg.delete({ timeout: 70000 })).catch(e => { if (config["main_config"].debugmode) return console.log(e); });
        message.delete().catch(s => { if (config["main_config"].debugmode) return console.log(e); });
    },
}
