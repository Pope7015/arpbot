module.exports = {
    name: 'publiccop',
    description: 'A Command.',
    aliases: ['credits', 'hyperz'],
    async execute(client, message, args, Hyperz, config) {
        const pingEmbed = new Hyperz.MessageEmbed()
            .setColor(config["main_config"].colorhex)
            .setTitle('Public Cop Information')
            .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, `${config["other_configuration"].serverinvite}`)
            .setDescription(`

            1 - ARP Staff Members are allowed to remove you from Public Cop.
            2 - Make sure to be in RTO (Depending on the AOP) you can find this in the Departments channel under DOJ catagory.
            3 - Any 'Fail Roleplay' will result in removal.
            4 - Try and be legit, we don't want to remove you.
            Note: LEO Applications are open 24/7. Make sure to apply at 
            https://bit.ly/LEOApp`)
            .setTimestamp()
            .setFooter(`${config["main_config"].copyright}`)

        message.channel.send(pingEmbed).then(msg => msg.delete({ timeout: 70000 })).catch(e => { if (config["main_config"].debugmode) return console.log(e); });
        message.delete().catch(e => { if (config["main_config"].debugmode) return console.log(e); });
    },
}
