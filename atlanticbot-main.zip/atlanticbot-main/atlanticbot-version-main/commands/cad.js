module.exports = {
    name: 'cad',
    description: 'A Command.',
    aliases: ['credits', 'hyperz'],
    async execute(client, message, args, Hyperz, config) {
        const pingEmbed = new Hyperz.MessageEmbed()
            .setColor(config["main_config"].colorhex)
            .setTitle('CAD/MDT Information')
            .setAuthor(`${message.author.tag}`, `${message.author.displayAvatarURL()}`, `${config["other_configuration"].serverinvite}`)
            .setDescription(`

            Gen-Cad link: https://gen-cad.com/
            Gen-Cad Invite Link: https://gen-cad.com/invite?code=CRPFiveM
            CAD Request Channel: #『:question:』cad-request`)
            .setTimestamp()
            .setFooter(`${config["main_config"].copyright}`)

        message.channel.send(pingEmbed).then(msg => msg.delete({ timeout: 70000 })).catch(e => { if (config["main_config"].debugmode) return console.log(e); });
        message.delete().catch(e => { if (config["main_config"].debugmode) return console.log(e); });
    },
}
